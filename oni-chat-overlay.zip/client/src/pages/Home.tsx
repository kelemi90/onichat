import { useMemo, useState } from "react";
import { Link } from "wouter";
import { DEFAULT_OVERLAY_CONFIG, type OverlayConfig } from "@shared/chat";
import { toOverlayUrl } from "@/lib/overlayConfig";
import OverlayPreview from "@/components/overlay/OverlayPreview";

type PreviewCanvas = "landscape" | "vertical";

export default function Home() {
  const [config, setConfig] = useState<OverlayConfig>({ ...DEFAULT_OVERLAY_CONFIG, demo: true });
  const [copied, setCopied] = useState(false);
  const [previewCanvas, setPreviewCanvas] = useState<PreviewCanvas>("landscape");
  const url = useMemo(() => toOverlayUrl(config), [config]);
  const update = <K extends keyof OverlayConfig>(key: K, value: OverlayConfig[K]) =>
    setConfig((current) => ({ ...current, [key]: value }));
  const copy = async () => {
    await navigator.clipboard.writeText(url);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  return (
    <main className="control-room">
      <div className="control-grid">
        <section className="control-intro">
          <p className="eyebrow">ONI // CHAT RELAY CONTROL ROOM</p>
          <h1>
            Make the chat feel<br /><span>alive after dark.</span>
          </h1>
          <p className="lede">
            A transparent neon-noir signal layer for your stream. Tune the atmosphere here, then drop the generated URL straight into OBS.
          </p>
          <div className="signal-card"><span className="signal-dot" /> <span>DEMO SIGNAL ONLINE</span><strong>WS / READY</strong></div>
          <Link href={`/overlay?demo=true&theme=${config.theme}&accent=${config.accent}`} className="preview-link">
            Open transparent overlay ↗
          </Link>
        </section>

        <section className="settings-panel">
          <div className="panel-heading"><span>LOCAL CONFIGURATION</span><span className="panel-index">SYS.01</span></div>
          <div className="form-row"><label>STREAMER ID<input value={config.tenant} onChange={(e) => update("tenant", e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 48))} placeholder="your_streamer_id" /></label><label>TWITCH CHANNEL<input value={config.channel} onChange={(e) => update("channel", e.target.value.replace(/^#/, "").toLowerCase())} placeholder="your_channel" /></label></div>
          <div className="form-row"><label>FONT SIZE<input type="number" min="12" max="42" value={config.fontSize} onChange={(e) => update("fontSize", Number(e.target.value))} /></label><label>MAX MESSAGES<input type="number" min="1" max="30" value={config.maxMessages} onChange={(e) => update("maxMessages", Number(e.target.value))} /></label></div>
          <div className="form-row"><label>DISPLAY SEC.<input type="number" min="2" max="120" value={config.duration} onChange={(e) => update("duration", Number(e.target.value))} /></label><label>CHAT WIDTH<input type="number" min="240" max="1000" value={config.width} onChange={(e) => update("width", Number(e.target.value))} /></label></div>
          <div className="form-row"><label>THEME<select value={config.theme} onChange={(e) => update("theme", e.target.value as OverlayConfig["theme"])}><option value="oni">CYBERPUNK ONI</option><option value="minimal">MINIMAL DARK</option><option value="matrix">MATRIX SIGNAL</option></select></label><label>ACCENT<select value={config.accent} onChange={(e) => update("accent", e.target.value as OverlayConfig["accent"])}><option value="magenta">HOT PINK</option><option value="cyan">ELECTRIC BLUE</option><option value="red">NEON RED</option></select></label></div>
          <div className="form-row"><label>ANIMATION<select value={config.animation} onChange={(e) => update("animation", e.target.value as OverlayConfig["animation"])}><option value="hud">HUD GLIDE</option><option value="slide">SOFT SLIDE</option><option value="fade">FADE ONLY</option><option value="none">STATIC</option></select></label><label>SPEED<select value={config.speed} onChange={(e) => update("speed", Number(e.target.value))}><option value="0.5">SLOW</option><option value="1">STANDARD</option><option value="1.5">FAST</option><option value="2">QUICK</option></select></label></div>
          <label className="toggle-line"><input type="checkbox" checked={config.demo} onChange={(e) => update("demo", e.target.checked)} /><span>USE DEMO SIGNAL</span><small>No credentials required</small></label>
          <label className="toggle-line"><input type="checkbox" checked={config.compact} onChange={(e) => update("compact", e.target.checked)} /><span>COMPACT MODE</span><small>More messages, less footprint</small></label>
          <div className="url-block"><span>OBS BROWSER SOURCE URL</span><code>{url}</code><button onClick={copy}>{copied ? "COPIED" : "COPY URL"}</button></div>
        </section>
      </div>

      <section className="preview-section" aria-labelledby="preview-heading">
        <div className="preview-section-heading">
          <div>
            <p className="eyebrow">OBS // LIVE STAGE PREVIEW</p>
            <h2 id="preview-heading">See the transparent overlay before you stream.</h2>
            <p>Demo messages are shown here against a checkerboard stage to represent OBS transparency. Your selected settings update this preview immediately.</p>
          </div>
          <div className="preview-switcher" aria-label="Preview canvas size">
            <button className={previewCanvas === "landscape" ? "is-active" : ""} onClick={() => setPreviewCanvas("landscape")}>16:9 LANDSCAPE</button>
            <button className={previewCanvas === "vertical" ? "is-active" : ""} onClick={() => setPreviewCanvas("vertical")}>9:16 VERTICAL</button>
          </div>
        </div>
        <OverlayPreview config={config} canvas={previewCanvas} />
      </section>

      <footer>ONI CHAT OVERLAY <span>LOCAL CONTROL / CREDENTIALS NEVER ENTER THE BROWSER</span></footer>
    </main>
  );
}
