import { useEffect, useState } from "react";
import type { OverlayConfig } from "@shared/chat";
import { useChatStream } from "@/hooks/useChatStream";
import { getActiveMessages } from "@/lib/messageLifecycle";
import ChatMessage from "@/components/overlay/ChatMessage";

type PreviewCanvas = "landscape" | "vertical";

type OverlayPreviewProps = {
  config: OverlayConfig;
  canvas: PreviewCanvas;
};

export default function OverlayPreview({ config, canvas }: OverlayPreviewProps) {
  const { messages, status } = useChatStream(config.tenant, config.channel, config.demo, config.maxMessages);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 500);
    return () => window.clearInterval(timer);
  }, []);

  const activeMessages = getActiveMessages(messages, now, config.duration);
  const canvasLabel = canvas === "vertical" ? "1080 × 1920 VERTICAL" : "1920 × 1080 LANDSCAPE";

  return (
    <div className={`preview-frame preview-frame-${canvas}`}>
      <div
        className={`overlay-shell preview-overlay theme-${config.theme} accent-${config.accent} ${config.compact ? "compact" : ""}`}
        style={{
          "--chat-width": `${config.width}px`,
          "--font-size": `${config.fontSize}px`,
          "--overlay-opacity": config.opacity,
        } as React.CSSProperties}
      >
        <div className="overlay-scanlines" aria-hidden="true" />
        <div className="overlay-corner overlay-corner-a" aria-hidden="true" />
        <div className="overlay-corner overlay-corner-b" aria-hidden="true" />
        <section className="chat-stack" aria-label="OBS overlay preview">
          {activeMessages.map((message) => (
            <ChatMessage
              key={message.id}
              message={message}
              duration={config.duration}
              showBadges={config.showBadges}
              showTimestamps={config.showTimestamps}
              showUsernames={config.showUsernames}
              showEmotes={config.showEmotes}
              compact={config.compact}
              animation={config.animation}
              speed={config.speed}
            />
          ))}
        </section>
        {!config.demo && status.state !== "connected" && (
          <div className="relay-status">{status.detail ?? "LINKING TO RELAY"}</div>
        )}
      </div>
      <div className="preview-canvas-label">{canvasLabel}</div>
    </div>
  );
}
