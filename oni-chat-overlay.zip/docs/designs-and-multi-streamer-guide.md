# Design Extensions and Multi-Streamer Guide

This guide explains how to add new visual designs to Oni Chat Overlay and how to use the deployment for other streamers.

## 1. How the current design system works

The overlay has three layers. `shared/chat.ts` defines the configuration vocabulary and the allowed theme names. `client/src/index.css` contains the visual tokens, layout rules, animations, and theme classes. `client/src/components/overlay/ChatMessage.tsx` renders one normalized chat message, including badges, emotes, cheers, subscriptions, raids, and username colors.

The current theme selector is in `client/src/pages/Home.tsx`. The overlay page and the in-page OBS preview both apply the same classes, so a theme added through the normal path appears consistently in the live Browser Source and the control-room preview.

| Area | File | Responsibility |
|---|---|---|
| Theme name contract | `shared/chat.ts` | Adds the allowed theme value and keeps URL parsing typed. |
| Control-room selector | `client/src/pages/Home.tsx` | Lets users choose the theme and serializes it into the overlay URL. |
| Theme colors and effects | `client/src/index.css` | Defines CSS variables, backgrounds, borders, glows, rails, and responsive behavior. |
| Message styling | `client/src/index.css` and `client/src/components/overlay/ChatMessage.tsx` | Controls message cards, event notices, badges, emotes, and animation states. |
| Preview rendering | `client/src/components/overlay/OverlayPreview.tsx` | Shows the same message renderer inside a checkerboard transparency stage. |
| URL validation | `client/src/lib/overlayConfig.ts` | Clamps safe values and rejects unsupported theme values. |

## 2. Adding a new theme

Choose a short lowercase identifier. For example, use `shrine` for a warm paper-and-incense design. Add the identifier to `ALLOWED_THEMES` in `shared/chat.ts` and add a matching option in the theme `<select>` in `client/src/pages/Home.tsx`:

```tsx
<option value="shrine">SHRINE NOIR</option>
```

Add a matching class to the theme selector in `client/src/index.css`. Theme variables should be defined on `.overlay-shell.theme-shrine`, because the same shell is used by the standalone overlay and the control-room preview:

```css
.overlay-shell.theme-shrine {
  --pink: #f1b36b;
  --cyan: #d8c6a2;
  --theme-ink: #211813;
  --theme-surface: rgba(36, 25, 19, .88);
}
```

Use the existing variables wherever possible. `--pink` is the primary accent used for event emphasis and the secondary corner line. `--cyan` is the cool signal color used for rails, borders, and status details. If the theme needs additional colors, define them on the theme class and reference them from descendant selectors rather than hard-coding colors throughout the file.

A complete theme normally includes the following visual decisions:

| Design decision | Existing hook |
|---|---|
| Primary and secondary accents | `--pink`, `--cyan` |
| Chat card surface | `.message-body` background |
| Message rail | `.message-rail` background and glow |
| Event notices | `.system-subscription`, `.system-raid` |
| Corner framing | `.overlay-corner-a`, `.overlay-corner-b` |
| Background treatment | `.overlay-shell.theme-*` and optional pseudo-elements |
| Accessibility | Keep text contrast, visible focus states, and reduced-motion behavior intact. |

Do not add a solid page background to the overlay shell. OBS needs the page outside the message cards to remain transparent. If a design needs texture, use transparent gradients, scanlines, or pseudo-elements with `pointer-events: none`.

## 3. Adding a new message treatment

Keep message data normalized in `OverlayChatMessage`. If the design only needs different colors or spacing, use CSS selectors. For example, subscription and raid events already expose `.system-subscription` and `.system-raid`.

If a new event needs new markup, extend the `system` union in `shared/chat.ts`, normalize the event in `relay/parser.ts`, and add the rendering branch in `ChatMessage.tsx`. Add a parser test before connecting it to Twitch. Never trust raw IRC text as HTML; continue rendering user text as React text and keep emote URLs constrained to the CDN resolver used by the existing parser.

## 4. Previewing and testing a new design

Run the web application locally, open the control room, keep **Use demo signal** enabled, and select the new theme. The preview stage uses a checkerboard background to represent transparency. Toggle between **16:9 LANDSCAPE** and **9:16 VERTICAL** to check both common OBS layouts. Use the `Open transparent overlay` link to inspect the actual Browser Source page without the control-room chrome.

Before packaging a theme, verify that it works at a narrow browser width, that long usernames and messages wrap, that event notices remain readable, and that `prefers-reduced-motion: reduce` disables non-essential movement. Run:

```bash
pnpm test -- --run
pnpm check
pnpm build
```

## 5. Can other streamers use this overlay?

Yes, but the current secure relay is intentionally configured for **one Twitch channel per deployment**. The relay reads `TWITCH_CHANNEL` from the server-only `.env`, joins that channel, and rejects Browser Source connections that request a different channel. This prevents an arbitrary public user from turning the relay into an uncontrolled multi-channel service.

The safest current method is one isolated Compose deployment per streamer. Give each streamer a separate directory, environment file, Twitch bot token, relay port, and hostname or path. The Browser Source URL for each streamer then points to that streamer’s deployment. This keeps credentials, logs, capacity limits, and channel routing separate.

| Use case | Recommended setup |
|---|---|
| Your own multiple channels | One deployment per channel, or extend the relay deliberately after adding authentication and per-channel limits. |
| A small number of trusted streamers | One Compose stack per streamer with separate `.env` and reverse-proxy hostname. |
| A public overlay service | Requires a multi-tenant relay redesign with authentication, channel authorization, per-tenant rate limits, token isolation, and operational monitoring. Do not expose the current single-channel relay as a public shared service. |

A separate deployment can reuse the same code and Docker image. Change at least these values in each stack’s `.env`:

```dotenv
TWITCH_BOT_USERNAME=streamer_specific_bot
TWITCH_OAUTH_TOKEN=streamer_specific_token
TWITCH_CHANNEL=streamer_channel
RELAY_PORT=8787
RELAY_ALLOWED_ORIGINS=https://streamer-host.example
```

If multiple stacks run on the same VM, each relay and web service must use different loopback ports, and the reverse proxy must route each hostname to the matching pair. Never share a Twitch token between unrelated streamers, and never place a token in a Browser Source URL.

## 6. Future multi-channel redesign

If one central installation is required later, the relay should be redesigned around a channel registry rather than a single global Twitch socket. Each authorized channel would need an isolated Twitch connection or an explicitly managed shared bot connection, a tenant identifier, an allowlisted origin, a client-to-channel binding, and independent limits. The WebSocket handshake must authenticate the tenant before it accepts a requested channel.

That change should be treated as a security feature, not just a UI feature. Add tests for cross-channel access, token separation, connection quotas, origin enforcement, and disconnect cleanup before enabling it in production.
